/**
 * 
 */
/**
 * @author USER
 *
 */
module MyBuddy {
	requires java.desktop;
	requires java.sql;
}